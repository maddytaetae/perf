/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6476014760147601, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.2857142857142857, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/recruitment/viewRecruitmentModule"], "isController": false}, {"data": [0.5357142857142857, 500, 1500, "clk on recruitemnet"], "isController": true}, {"data": [1.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/dashboard/pendingLeaveRequests"], "isController": false}, {"data": [0.05, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/time/viewTimeModule"], "isController": false}, {"data": [0.0, 500, 1500, "Login"], "isController": true}, {"data": [1.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/dashboard/employeeDistribution"], "isController": false}, {"data": [1.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/webres_5bdfdad33dec87.24121780/orangehrmDashboardPlugin/js/flot/jquery.flot.pie.min.js?_=1624356972326"], "isController": false}, {"data": [0.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/auth/validateCredentials"], "isController": false}, {"data": [1.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/recruitment/getVacancyListForJobTitleJson/mode/candidates/jobTitle/"], "isController": false}, {"data": [1.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/recruitment/getHiringManagerListJson/mode/candidates/jobTitle/"], "isController": false}, {"data": [0.9642857142857143, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/leave/getWorkWeekAjax?_=1624356976096"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.4666666666666667, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/webres_5bdfdad33dec87.24121780/orangehrmDashboardPlugin/js/flot/jquery.flot.min.js?_=1624356971949"], "isController": false}, {"data": [1.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/recruitment/getHiringManagerListJson/mode/candidates/vacancyId/"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.2692307692307692, 500, 1500, "Clk on Time"], "isController": true}, {"data": [0.5, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/webres_5bdfdad33dec87.24121780/orangehrmDashboardPlugin/js/flot/JUMFlot.min.js?_=1624356972501"], "isController": false}, {"data": [0.7, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/auth/login"], "isController": false}, {"data": [1.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/webres_5bdfdad33dec87.24121780/orangehrmDashboardPlugin/js/graph-visualizer/pie-chart.js?_=1624356972942"], "isController": false}, {"data": [1.0, 500, 1500, "https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/leave/getHolidayAjax?year=2021&_=1624356976095"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 224, 0, 0.0, 676.3125, 0, 16851, 245.5, 1782.0, 1962.25, 2910.25, 2.234614578864935, 28.362817484861484, 1.0099001250735726], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/recruitment/viewRecruitmentModule", 14, 0, 0.0, 1379.642857142857, 1074, 1858, 1179.0, 1811.0, 1858.0, 1858.0, 0.17077544249136972, 2.7803304619170763, 0.14008923016870173], "isController": false}, {"data": ["clk on recruitemnet", 14, 0, 0.0, 656.9285714285714, 249, 981, 670.0, 843.0, 981.0, 981.0, 0.17293558149589278, 0.18480560187758632, 0.18194666404175158], "isController": true}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/dashboard/pendingLeaveRequests", 15, 0, 0.0, 240.13333333333335, 211, 265, 246.0, 260.8, 265.0, 265.0, 0.17148344613133346, 0.26844527748879643, 0.0502392908587891], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/time/viewTimeModule", 10, 0, 0.0, 1804.7000000000003, 1115, 2812, 1646.5, 2777.5, 2812.0, 2812.0, 0.17205189085028044, 2.8012030459636628, 0.138784044767902], "isController": false}, {"data": ["Login", 15, 0, 0.0, 8036.266666666666, 5926, 16851, 7425.0, 12490.800000000003, 16851.0, 16851.0, 0.14963638358788145, 25.65146576631286, 0.7550402521871852], "isController": true}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/dashboard/employeeDistribution", 15, 0, 0.0, 226.73333333333335, 202, 258, 223.0, 254.4, 258.0, 258.0, 0.17153835597639633, 0.3477672138740222, 0.05025537772745986], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/webres_5bdfdad33dec87.24121780/orangehrmDashboardPlugin/js/flot/jquery.flot.pie.min.js?_=1624356972326", 14, 0, 0.0, 219.57142857142858, 171, 380, 180.5, 375.0, 380.0, 380.0, 0.1759545534524797, 2.1630038270115377, 0.07921391517733706], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/auth/validateCredentials", 15, 0, 0.0, 2101.3333333333335, 1797, 2943, 1865.0, 2785.2000000000003, 2943.0, 2943.0, 0.16823310378860948, 2.766645964648617, 0.16954742491195798], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/recruitment/getVacancyListForJobTitleJson/mode/candidates/jobTitle/", 14, 0, 0.0, 239.85714285714286, 200, 389, 224.5, 329.0, 389.0, 389.0, 0.17293558149589278, 0.06468196065715522, 0.06417531344574147], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/recruitment/getHiringManagerListJson/mode/candidates/jobTitle/", 13, 0, 0.0, 226.84615384615387, 200, 288, 222.0, 270.79999999999995, 288.0, 288.0, 0.16516745438837221, 0.061776499053463434, 0.06048612831605428], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/leave/getWorkWeekAjax?_=1624356976096", 14, 0, 0.0, 247.0, 196, 540, 224.5, 405.5, 540.0, 540.0, 0.17286725029943079, 0.06347469346932225, 0.05908548594218826], "isController": false}, {"data": ["Debug Sampler", 10, 0, 0.0, 0.10000000000000002, 0, 1, 0.0, 0.9000000000000004, 1.0, 1.0, 0.17741191498421036, 0.10142278811694994, 0.0], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/webres_5bdfdad33dec87.24121780/orangehrmDashboardPlugin/js/flot/jquery.flot.min.js?_=1624356971949", 15, 0, 0.0, 927.5333333333334, 670, 1969, 779.0, 1610.2000000000003, 1969.0, 1969.0, 0.1703771013175829, 8.880074486738982, 0.0760374368184916], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/recruitment/getHiringManagerListJson/mode/candidates/vacancyId/", 13, 0, 0.0, 222.30769230769232, 201, 304, 215.0, 279.2, 304.0, 304.0, 0.16511291182970508, 0.061756098858180716, 0.06062739731246984], "isController": false}, {"data": ["Test", 10, 0, 0.0, 10241.399999999998, 8426, 12201, 10401.0, 12087.9, 12201.0, 12201.0, 0.1888788153520701, 36.79298453908847, 1.3500039546501963], "isController": true}, {"data": ["Clk on Time", 13, 0, 0.0, 1388.2307692307695, 0, 2812, 1636.0, 2674.0, 2812.0, 2812.0, 0.16565996380966944, 2.0747193138810305, 0.10279081288069933], "isController": true}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/webres_5bdfdad33dec87.24121780/orangehrmDashboardPlugin/js/flot/JUMFlot.min.js?_=1624356972501", 14, 0, 0.0, 762.3571428571429, 666, 1188, 712.0, 1012.5, 1188.0, 1188.0, 0.175153259101714, 9.998616953897159, 0.07748479137995745], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/auth/login", 15, 0, 0.0, 832.6, 362, 2004, 397.0, 1878.6000000000001, 2004.0, 2004.0, 0.17910020059222465, 2.814764871286656, 0.06069118125537301], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/webres_5bdfdad33dec87.24121780/orangehrmDashboardPlugin/js/graph-visualizer/pie-chart.js?_=1624356972942", 14, 0, 0.0, 182.64285714285714, 166, 296, 174.0, 243.5, 296.0, 296.0, 0.17662717787618434, 0.5548922179957861, 0.07986170249675131], "isController": false}, {"data": ["https://s2.demo.opensourcecms.com/orangehrm/symfony/web/index.php/leave/getHolidayAjax?year=2021&_=1624356976095", 14, 0, 0.0, 224.78571428571428, 199, 373, 209.0, 313.0, 373.0, 373.0, 0.17293985398935185, 0.0607991674181315, 0.06063028084197003], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 224, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
